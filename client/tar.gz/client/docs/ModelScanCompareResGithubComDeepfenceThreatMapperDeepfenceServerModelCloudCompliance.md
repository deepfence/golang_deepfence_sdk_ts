# ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**New** | [**[]ModelCloudCompliance**](ModelCloudCompliance.md) |  | 

## Methods

### NewModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance

`func NewModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance(new []ModelCloudCompliance, ) *ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance`

NewModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance instantiates a new ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudComplianceWithDefaults

`func NewModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudComplianceWithDefaults() *ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance`

NewModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudComplianceWithDefaults instantiates a new ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNew

`func (o *ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance) GetNew() []ModelCloudCompliance`

GetNew returns the New field if non-nil, zero value otherwise.

### GetNewOk

`func (o *ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance) GetNewOk() (*[]ModelCloudCompliance, bool)`

GetNewOk returns a tuple with the New field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNew

`func (o *ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance) SetNew(v []ModelCloudCompliance)`

SetNew sets New field to given value.


### SetNewNil

`func (o *ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance) SetNewNil(b bool)`

 SetNewNil sets the value for New to be an explicit nil

### UnsetNew
`func (o *ModelScanCompareResGithubComDeepfenceThreatMapperDeepfenceServerModelCloudCompliance) UnsetNew()`

UnsetNew ensures that no value is present for New, not even an explicit nil

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


