# ModelBenchmarkType

## Enum


* `HIPAA` (value: `"hipaa"`)

* `GDPR` (value: `"gdpr"`)

* `PCI` (value: `"pci"`)

* `NIST` (value: `"nist"`)

* `CIS` (value: `"cis"`)

* `SOC_2` (value: `"soc_2"`)

* `NSA_CISA` (value: `"nsa-cisa"`)

* `AWS_FOUNDATIONAL_SECURITY` (value: `"aws_foundational_security"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


